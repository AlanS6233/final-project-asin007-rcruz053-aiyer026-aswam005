#include "../include/UserInterface.h"
#include "../include/Person.h"
#include "../include/TaskSorter.h"
#include "../include/Task.h"
#include "../include/DBManager.h"

int main() {
    UserInterface UI;
    UI.startupMenu();
}